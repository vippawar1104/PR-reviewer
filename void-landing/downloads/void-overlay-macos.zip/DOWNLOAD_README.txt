Void — macOS overlay

Since this build isn't notarized by Apple, macOS will likely block it on first launch
with a message like "cannot be opened because the developer cannot be verified."

To run it anyway:

  1. Open Terminal, cd to wherever you unzipped this
  2. Run: xattr -cr overlay-app
  3. Run: ./overlay-app

Or via Finder: right-click overlay-app -> Open -> click "Open" on the warning dialog.

The overlay connects to a Void backend running at ws://127.0.0.1:8123/ws/activity by
default — make sure the backend is running first.
